package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.model.Book;
import com.cg.model.Library;
import com.cg.service.BookService;

@Controller
public class BookController {

	@Autowired BookService bookService;
	
     @PostMapping("/home")
     public String addBook(@ModelAttribute("book") Book book,@ModelAttribute("library")Library library) {
    	   book.setLibrary(library);
           bookService.insertBook(book);
           return "index.jsp"; 
     }

     @GetMapping("/find")
     public String findBook(@RequestParam("id")String bookId)
     {
    	 bookService.findBook(bookId);
    	 return "find.jsp";
     }
     
     @PostMapping("/delete")
     public String deleteBook(@RequestParam("id") String bookId) {
           bookService.deleteBook(bookId);
           return "index.jsp";  
     }

     @GetMapping("/update")
     public String editEmployee(@RequestParam String bookId, @RequestParam String bookName,
 			@RequestParam String author, @RequestParam String publisher) {
           bookService.updateBook(bookId, bookName, author, publisher);
           return "update.jsp";
     }

	
	

}